const styles = theme => ({
    grow: {
        flexGrow: 1,
    },
    root: {
        minHeight: "100vh"
    },
});

export default styles;